Implementacion de la Tarea #1 para el ramo de computacion grafica:

Los contenidos de la raiz este archivo .zip deben ser descomprimidos en una carpeta llamada
Tarea-1 ubicada en la raiz del repositorio del curso.

Luego basta correr el archivo Tarea1.py
